import React, { useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

// --- CONFIG ---
// IMPORTANT: set Vercel env var VITE_TMDB_KEY to your TMDB v3 key.
const TMDB_KEY = import.meta.env.VITE_TMDB_KEY
const TMDB_BASE = 'https://api.themoviedb.org/3'
const IMG = (path, size='w500') => (path ? `https://image.tmdb.org/t/p/${size}${path}` : '')

export default function App() {
  // UI state
  const [searchTerm, setSearchTerm] = useState('')
  const [chatOpen, setChatOpen] = useState(false)
  const [messages, setMessages] = useState([
    { sender: 'bot', text: 'Hey! Which K-drama are you into right now?' }
  ])
  const [input, setInput] = useState('')

  // Data state
  const [popular, setPopular] = useState([])
  const [topRated, setTopRated] = useState([])
  const [airing, setAiring] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  // Modal state
  const [openItem, setOpenItem] = useState(null) // tv object with details
  const [trailerUrl, setTrailerUrl] = useState('')
  const [aiReview, setAiReview] = useState('')
  const [aiLoading, setAiLoading] = useState(false)

  const fetchJSON = async (url) => {
    const res = await fetch(url)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    return res.json()
  }

  const fetchSection = async (params) => {
    // params: { sort_by, page }
    const qs = new URLSearchParams({
      api_key: TMDB_KEY,
      with_original_language: 'ko',
      include_adult: 'false',
      page: String(params.page || 1),
      sort_by: params.sort_by || 'popularity.desc'
    })
    return fetchJSON(`${TMDB_BASE}/discover/tv?${qs.toString()}`)
  }

  useEffect(() => {
    let alive = true
    ;(async () => {
      try {
        setLoading(true)
        if (!TMDB_KEY) throw new Error('Missing TMDB key (VITE_TMDB_KEY).')

        const [pop, top, air] = await Promise.all([
          fetchSection({ sort_by: 'popularity.desc', page: 1 }),
          fetchSection({ sort_by: 'vote_average.desc', page: 1 }),
          fetchJSON(`${TMDB_BASE}/tv/airing_today?api_key=${TMDB_KEY}&language=en-US&page=1`)
        ])

        if (!alive) return
        const airingKo = (air.results || []).filter(
          (s) => (s.original_language === 'ko') || (s.origin_country || []).includes('KR')
        )

        setPopular((pop.results || []).slice(0, 18))
        setTopRated((top.results || []).filter(r => r.vote_count > 200).slice(0, 18))
        setAiring(airingKo.slice(0, 18))
        setError('')
      } catch (e) {
        console.error(e)
        setError('Failed to load data. Check API key or network.')
      } finally {
        setLoading(false)
      }
    })()
    return () => { alive = false }
  }, [])

  const filtered = useMemo(() => {
    const q = searchTerm.trim().toLowerCase()
    if (!q) return null
    const all = [...popular, ...topRated, ...airing]
    const byName = all.filter((s) => (s.name || '').toLowerCase().includes(q))
    return byName.slice(0, 24)
  }, [searchTerm, popular, topRated, airing])

  const openDetails = async (item) => {
    setOpenItem(item)
    setTrailerUrl('')
    setAiReview('')

    try {
      const vids = await fetchJSON(`${TMDB_BASE}/tv/${item.id}/videos?api_key=${TMDB_KEY}&language=en-US`)
      const trailer = (vids.results || []).find(v => v.type === 'Trailer' && v.site === 'YouTube')
        || (vids.results || []).find(v => v.site === 'YouTube')
      if (trailer) setTrailerUrl(`https://www.youtube.com/watch?v=${trailer.key}`)
    } catch {}
  }

  const closeDetails = () => {
    setOpenItem(null)
    setTrailerUrl('')
    setAiReview('')
  }

  const makeAiReview = (item) => {
    setAiLoading(true)
    setTimeout(() => {
      const votes = item.vote_average || 0
      const tone = votes >= 8.5 ? 'Masterpiece drama with powerful emotions.'
        : votes >= 7.8 ? 'Highly engaging with strong performances.'
        : votes >= 7.0 ? 'Good watch, balanced storytelling.'
        : 'Niche appeal; try if you like the genre.'
      const blurb = (item.overview || '').split('.').slice(0, 2).join('.').trim()
      setAiReview(`${tone}${blurb ? `\n\nQuick take: ${blurb}.` : ''}`)
      setAiLoading(false)
    }, 500)
  }

  const sendMessage = () => {
    if (!input.trim()) return
    const newMessages = [...messages, { sender: 'user', text: input }]
    const reply = generateAIReply(input)
    setMessages([...newMessages, { sender: 'bot', text: reply }])
    setInput('')
  }

  const generateAIReply = (msg) => {
    const m = msg.toLowerCase()
    if (m.includes('romance')) return 'Try Queen of Tears, Crash Landing on You, or Goblin.'
    if (m.includes('thriller') || m.includes('crime')) return 'Flower of Evil, Signal, or Mouse will hook you.'
    if (m.includes('school')) return 'Weak Hero Class 1 and True Beauty are solid picks.'
    if (m.includes('fantasy')) return 'Goblin and My Love from the Star never miss.'
    return 'Tell me a mood or genre (romance, thriller, school, fantasy) and I’ll suggest three.'
  }

  const Section = ({ title, items }) => (
    <section className="section container">
      <h3>{title}</h3>
      {items.length === 0 ? (
        <p style={{color:'#a8a8a8', fontSize:14}}>No items.</p>
      ) : (
        <div className="grid">
          {items.map((s) => (
            <div key={`${title}-${s.id}`} className="card" onClick={() => openDetails(s)}>
              {s.poster_path ? (
                <img src={IMG(s.poster_path, 'w342')} alt={s.name} className="poster" />
              ) : (
                <div className="poster" />
              )}
              <h4 title={s.name}>{s.name}</h4>
              <div className="rating">⭐ {(s.vote_average || 0).toFixed(1)}</div>
            </div>
          ))}
        </div>
      )}
    </section>
  )

  const hero = useMemo(() => popular[0] || topRated[0] || airing[0], [popular, topRated, airing])

  return (
    <div>
      {/* Header */}
      <div className="header">
        <div className="header-inner container">
          <a className="brand" href="https://www.youtube.com/@KSyncLab" target="_blank" rel="noreferrer">KSyncLab</a>
          <div className="subtitle">AI K-Drama World • click title for YouTube</div>
        </div>
      </div>

      {/* Hero */}
      <section className="hero">
        <div className="hero-inner container">
          <motion.h1 initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            Feel the K-Drama
          </motion.h1>
          <p>Discover Korean dramas by popularity, ratings, and what’s airing now. Click any poster for details, trailers, and a quick AI review.</p>
          <div className="search">
            <span style={{color:'#a8a8a8'}}>Search</span>
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search a title (e.g., Goblin, Queen of Tears)"
            />
            <button className="btn" onClick={() => setSearchTerm('')}>Clear</button>
          </div>
        </div>
      </section>

      {/* Sections */}
      {error && <p style={{textAlign:'center', color:'#ff6b6b', marginTop:12}}>{error}</p>}
      {loading ? (
        <p style={{textAlign:'center', color:'#bbb', padding:'32px 0'}}>Loading K-dramas…</p>
      ) : (
        <>
          {filtered ? (
            <Section title={`Search Results`} items={filtered} />
          ) : (
            <>
              <Section title={`Popular K-Dramas`} items={popular} />
              <Section title={`Top Rated K-Dramas`} items={topRated} />
              <Section title={`Airing Now`} items={airing} />
            </>
          )}
        </>
      )}

      {/* Footer */}
      <div className="footer">© 2025 KSyncLab • Red & Black theme • Built for K-drama lovers</div>

      {/* Chatbot */}
      <button className="fab" onClick={() => setChatOpen(v => !v)} title="Chat">💬</button>
      <AnimatePresence>
        {chatOpen && (
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 40 }}
            className="chat"
          >
            <div className="chat-messages">
              {messages.map((m, i) => (
                <div key={i} className={`bubble ${m.sender === 'user' ? 'user' : 'bot'}`}>
                  {m.text}
                </div>
              ))}
            </div>
            <div className="chat-input">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Chat about K-dramas…"
                onKeyDown={(e) => { if (e.key === 'Enter') sendMessage() }}
              />
              <button className="btn" onClick={sendMessage}>Send</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Details Modal */}
      <AnimatePresence>
        {openItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="modal-backdrop"
            onClick={(e) => { if (e.target.classList.contains('modal-backdrop')) closeDetails() }}
          >
            <motion.div
              initial={{ scale: 0.98, y: 10, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.98, y: 10, opacity: 0 }}
              className="modal"
            >
              <div className="modal-header">
                {openItem.backdrop_path && <img src={IMG(openItem.backdrop_path, 'w1280')} alt={openItem.name} className="modal-banner" />}
                <div className="modal-grad"></div>
                <button className="modal-close" onClick={closeDetails}>✕</button>
              </div>
              <div className="modal-body">
                <div>
                  {openItem.poster_path ? (
                    <img src={IMG(openItem.poster_path, 'w342')} alt={openItem.name} style={{borderRadius:12, width:'100%'}}/>
                  ) : (
                    <div style={{height:280, background:'#222', borderRadius:12}}/>
                  )}
                </div>
                <div>
                  <h2 style={{margin:'0 0 6px 0'}}>{openItem.name}</h2>
                  <div className="meta">
                    <div>⭐ {(openItem.vote_average || 0).toFixed(1)}</div>
                    <div>First aired: {(openItem.first_air_date || '').slice(0,4) || '—'}</div>
                    <div>Language: {(openItem.original_language || '').toUpperCase()}</div>
                  </div>
                  <p className="overview">{openItem.overview || 'No description available.'}</p>
                  <div style={{display:'flex', gap:10, flexWrap:'wrap', marginTop:10}}>
                    {trailerUrl && (
                      <a href={trailerUrl} target="_blank" rel="noreferrer" className="btn">▶ Watch Trailer</a>
                    )}
                    <button className="btn secondary" onClick={() => makeAiReview(openItem)} disabled={aiLoading}>
                      {aiLoading ? 'Analyzing…' : 'AI Review'}
                    </button>
                  </div>
                  {aiReview && (
                    <div style={{marginTop:12}}>
                      <div style={{display:'inline-block', background:'#141414', border:'1px solid var(--border)', padding:'10px 12px', borderRadius:12, whiteSpace:'pre-wrap'}}>
                        {aiReview}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
